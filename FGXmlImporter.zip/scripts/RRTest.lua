function onInit()
    print("TEST SCRIPT LOADED");
end

function printRecords(w)
  local tFilteredRecords = {};
	for _,v in pairs(ListManager.helperGetRecords(w)) do
		if ListManager.helperIsFilteredRecord(w, v) then
			table.insert(tFilteredRecords, v);
		end
	end

  for _,v in pairs(tFilteredRecords) do
    print(v.vNode.getName());
    print(v.vNode.getPath());
  end
end