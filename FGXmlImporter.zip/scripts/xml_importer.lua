function onInit()
	aRecords = LibraryData.getRecordTypes();
	for kRecordType,vRecordType in pairs(aRecords) do
        if vRecordType == "item" then
            LibraryData.addIndexButton(vRecordType, "button_xmlimporter_importitem");
        end
	end
end