local bDeleteOnSave = false;

function onInit()
	aRecords = LibraryData.getRecordTypes();
	for kRecordType,vRecordType in pairs(aRecords) do
        if vRecordType == "item" then
            LibraryData.addIndexButton(vRecordType, "button_xmlimporter_importitem");
        end

        if vRecordType == "spell" then
            LibraryData.addIndexButton(vRecordType, "button_xmlimporter_importspell");
        end

		if vRecordType == "story" then
			LibraryData.addIndexButton(vRecordType, "button_xmlimporter_importstory");
		end
	end
end

local sImportRecordType = "";
function importItem()
    sImportRecordType = "item";
    Interface.dialogFileOpen(XmlImporter.onImportFileSelection, nil, nil, true);
end

function importSpell()
    sImportRecordType = "spell";
    Interface.dialogFileOpen(XmlImporter.onImportFileSelection, nil, nil, true);
end

function importStory()
	ChatManager.SystemMessage("FUNCTION IN DEVELOPMENT");
end

function exportStory()
	ChatManager.SystemMessage("FUNCTION IN DEVELOPMENT");

end

function onImportFileSelection(result, vPath)
	if result ~= "ok" then return; end
	
	if sImportRecordType == "item" or sImportRecordType == "spell" then
		local sRootMapping = LibraryData.getRootMapping(sImportRecordType);
		if sRootMapping then
			if type(vPath) == "table" then
				for _,v in ipairs(vPath) do
					DB.import(v, sRootMapping, sImportRecordType);
					ChatManager.SystemMessage(Interface.getString("message_slashimportsuccess") .. ": " .. v);
				end
			else
				DB.import(vPath, sRootMapping, sImportRecordType);
				ChatManager.SystemMessage(Interface.getString("message_slashimportsuccess") .. ": " .. vPath);
			end
		end
	end
end

local sExportRecordPath = "";
local sExportRecordType = "";
function exportRecord(recordType, nodeRecord)
	sExportRecordType = recordType;
	if nodeRecord then
		--if module-owned, have to temporarily duplicate it to allow export
		if DB.getModule(nodeRecord) then
			sRecordPath = DB.getPath(nodeRecord);			
			sRootMapping = LibraryData.getRootMapping(recordType);

			cloneRecord = DB.createChildAndCopy(sRootMapping, nodeRecord);
			cloneRecord.setCategory("XmlImporter Temp");

			sExportRecordPath = DB.getPath(cloneRecord);
			bDeleteOnSave = true;
		else
			sExportRecordPath = DB.getPath(nodeRecord);
		end
	else
		sExportRecordPath = "";
	end
	Interface.dialogFileSave(XmlImporter.onExportFileSelection);
end

function onExportFileSelection(result, path)
	if result == "ok" then 
		if sExportRecordType == "story" then
			if (sExportRecordPath or "") ~= "" then
				DB.export(path, sExportRecordPath, "story");
			else
				local sRootMapping = LibraryData.getRootMapping(sExportRecordType);
				if sRootMapping then
					DB.export(path, sRootMapping, "story", true);
				end
			end
		end
	end
		
	if bDeleteOnSave then
		DB.deleteNode(sExportRecordPath);
	end
	bDeleteOnSave = false;
end